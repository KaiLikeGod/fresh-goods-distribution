package cn.edu.zucc.distribution;

import cn.edu.zucc.distribution.ui.FrmMain;

public class DistributionStarter {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new FrmMain();
	}

}
