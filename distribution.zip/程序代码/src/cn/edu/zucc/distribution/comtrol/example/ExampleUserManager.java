package cn.edu.zucc.distribution.comtrol.example;

import cn.edu.zucc.distribution.itf.IUserManager;
import cn.edu.zucc.distribution.model.BeanUser;
import cn.edu.zucc.distribution.util.BaseException;
import cn.edu.zucc.distribution.util.BusinessException;
import cn.edu.zucc.distribution.util.DBUtil;
import cn.edu.zucc.distribution.util.DbException;
import javax.swing.JOptionPane;

import java.util.Date;
import java.sql.*;

public class ExampleUserManager implements IUserManager {

	@Override
	public BeanUser reg(String userid, String pwd,String pwd2) throws BaseException {
		if (userid==null || "".equals(userid)) throw new BusinessException("�˺Ų���Ϊ��");
		if (pwd==null || "".equals(pwd)) throw new BusinessException("���벻��Ϊ��");
		if (!pwd.equals(pwd2)) throw new BusinessException("������������벻һ��");
		Connection conn=null;
		try {
			conn= DBUtil.getConnection();
			//����û��Ƿ��Ѿ�����
			String sql="SELECT user_id\n" +
					"FROM tbl_user WHERE user_id=?";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,userid);
			ResultSet rs=pst.executeQuery();
			if (rs.next()){
				rs.close();
				pst.close();
				throw new BusinessException("�û��Ѵ���");
			}
			rs.close();
			pst.close();
			sql="INSERT INTO tbl_user(user_id,user_pwd,register_time)\n" +
					"VALUES (?,?,?)\n";
			pst=conn.prepareStatement(sql);
			pst.setString(1,userid);
			pst.setString(2,pwd);
			pst.setTimestamp(3,new Timestamp(System.currentTimeMillis()));
			pst.execute();
			BeanUser user=new BeanUser();
			user.setRegister_time(new Date());
			user.setUser_id(userid);
			user.setPwd(pwd);
			return user;
		}catch (SQLException ex){
			throw new DbException(ex);
		}finally {
			if (conn!=null){
				try {
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
	}

	
	@Override
	public BeanUser login(String userid, String pwd) throws BaseException {
		Connection conn=null;
		BeanUser user=null;
		if(pwd==null){
			//TODO
		}
		try {
			conn= DBUtil.getConnection();
			String sql="SELECT register_time\n" +
					"FROM tbl_user WHERE user_id=? AND user_pwd=?";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,userid);
			pst.setString(2,pwd);
			ResultSet rs=pst.executeQuery();
			if (rs.next()){
				user=new BeanUser();
				user.setUser_id(userid);
				user.setRegister_time(rs.getTimestamp(1));
				return user;
			}else {
				throw new BusinessException("�û������ڻ��������");
			}
		}catch (SQLException ex){
			throw new DbException(ex);
		}finally {
			if (conn!=null){
				try {
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
	}


	@Override
	public void changePwd(BeanUser user, String oldPwd, String newPwd,
			String newPwd2) throws BaseException {
		// TODO Auto-generated method stub
		if (oldPwd==null || "".equals(oldPwd)) throw new BusinessException("ԭ���벻��Ϊ��");
		Connection conn=null;
		try {
			conn= DBUtil.getConnection();
			String sql="SELECT user_pwd\n" +
					"FROM tbl_user \n" +
					"WHERE user_id=?";
			PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1,user.getUser_id());
			ResultSet rs=pst.executeQuery();
			if (rs.next()){
				if (!oldPwd.equals(rs.getString(1))) {
					rs.close();
					pst.close();
					throw new BusinessException("ԭ�����������");
				}
			}
			rs.close();
			pst.close();
			if (newPwd==null || "".equals(newPwd)) throw new BusinessException("������������");
			if (!newPwd.equals(newPwd2)) throw new BusinessException("�����������벻һ�£�");
			sql="UPDATE tbl_user SET user_pwd=? WHERE user_id=?\n";
			pst=conn.prepareStatement(sql);
			pst.setString(1,newPwd);
			pst.setString(2,user.getUser_id());
			pst.execute();
			pst.close();
			JOptionPane.showMessageDialog(null, "success! ", "��ʾ" , JOptionPane.PLAIN_MESSAGE);
		}catch (SQLException ex){
			throw new DbException(ex);
		}finally {
			if (conn!=null){
				try {
					conn.close();
				}catch (SQLException e){
					e.printStackTrace();
				}
			}
		}
	}

}





