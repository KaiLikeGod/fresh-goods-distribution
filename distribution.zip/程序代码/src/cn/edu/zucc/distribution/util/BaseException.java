package cn.edu.zucc.distribution.util;

public class BaseException  extends Exception {
	public BaseException(String msg){
		super(msg);
	}
}
