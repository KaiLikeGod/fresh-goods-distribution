package cn.edu.zucc.distribution.util;

public class BusinessException extends BaseException {
	public BusinessException(String msg){
		super(msg);
	}
}
